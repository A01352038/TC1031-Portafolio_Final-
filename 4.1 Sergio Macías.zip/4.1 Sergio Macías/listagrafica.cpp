#include "listgrafica.h"

template <class T>
listgrafica<T>::listgrafica(bool dir)
{
    directed = dir;
    size = 0;
}

/**
 * @brief Destroy the UListGraph<T>::UListGraph object
 *
 */
template <class T>
listgrafica<T>::~listgrafica()
{
    vertexes.clear();
    edges.clear();
}

//Complejidad: O(log(size))
template <class T>
void listgrafica<T>::adEdge(T from, T to)
{
    if (!isVertex(from))
        adVer(from);

    if (!isVertex(to))
        adVer(to);

    edges.at(from).insert(to);

    if (!directed)
        edges.at(to).insert(from);
}

//Complejidad: O(log(size))
template <class T>
void listagafica<T>::removeEdge(T from, T to)
{
    if (!isVertex(from) || !isVertex(to))
        return;

    edges.at(from).erase(to);

    if (!directed)
        edges.at(to).erase(from);
}

//Complejidad: O(log(size))
template <class T>
void listagrafica<T>::adVer(T vertex)
{
    if (isVertex(vertex))
        return;

    vertexes.insert(vertex);
    edges.insert({vertex, std::set<T>()});
    size++;
}

//Complejidad: O(log(size))
template <class T>
void listagrafica<T>::remVer(T vertex)
{
    if (!isVertex(vertex))
        return;

    edges.erase(vertex);
    vertexes.erase(vertex);
    size--;
}

// Complejidad: O(log(size))
template <class T>
bool listagrafica<T>::isEdge(T from, T to) const
{
    if (!isVertex(from) || !isVertex(to))
        return false;

    return edges.at(from).find(to) != edges.at(from).end();
}

//Complexity: O(log(size))
template <class T>
bool listagrafica<T>::isVertex(T vertex) const
{
    return vertexes.find(vertex) != vertexes.end();
}

//Complexity: O(size)

template <class T>
std::vector<T> listagrafica<T>::getVert() const
{
    return std::vector(vertexes.begin(), vertexes.end());
}

//Complexity: O(Edges)
template <class T>
std::vector<T> listagrafica<T>::getNB(T vertex) const
{
    return std::vector<T>(edges.at(vertex).begin(), edges.at(vertex).end());
}

/**
 * @brief Overload for stream printing of graphs
 *
 * @return std::ostream&
 */
template <class T>
std::ostream &operator<<(std::ostream &out, listagrafica<T> &graph)
{
    for (auto vertex : graph.vertexes)
    {
        out << vertex << " -> ";

        for (auto neighbour : graph.edges.at(vertex))
            out << neighbour << " ";

        out << std::endl;
    }

    return out;
}
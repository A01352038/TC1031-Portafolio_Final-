#ifndef listagrafica_h
#define listagrafica_h

#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <fstream>
#include "grafica.h"

template <class T>
class listagrafica : public grafica<T>
{
public:
    listagrafica(bool dir = false);
    ~listagrafica();

    void adEdge(T, T);
    void remEdge(T, T);
    void adVer(T);
    void remVer(T);
    bool isEdge(T, T) const;
    bool isVertex(T) const;

    std::vector<T> getVert() const;
    std::vector<T> getNB(T) const;

    template <class U>
    friend std::ostream &operator<<(std::ostream &, listagrafica<U> &);

private:
    int size;
    bool directed;
    std::set<T> vertexes;
    std::map<T, std::set<T>> edges;
};
#endif
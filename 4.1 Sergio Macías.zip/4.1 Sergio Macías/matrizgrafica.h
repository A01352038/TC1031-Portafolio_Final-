#ifndef matrizgrafica_h
#define matrizgrafica_h

#include <vector>
#include <set>
#include <stack>
#include <queue>
#include <iostream>
#include <fstream>
#include "grafica.h"

template <class T>
class matrizgrafica : public grafica<T>
{
public:
    matrizgrafica(int, bool dir = false);
    ~matrizgrafica();

    void loadGraph(int, std::ifstream &);

    void adEdge(T, T);
    void remEdge(T, T);
    void adVer(T);
    void remVer(T);
    bool isEdge(T, T) const;
    bool isVertex(T) const;

    std::vector<T> getVert() const;
    std::vector<T> getNB(T) const;

    template <class U>
    friend std::ostream &operator<<(std::ostream &, matrizgrafica<U> &);

private:
    int size;
    int capacity;
    bool directed;
    std::vector<T> vertexes;
    std::vector<std::vector<bool>> edges;

    int getIndexOf(T) const;
};
#endif
#include "matrizgrafica.h"

//Complexity: O(cap^2)
template <class T>
UMatrixGraph<T>::matrizgrafica(int cap, bool dir)
{
    capacity = cap;
    size = 0;
    directed = dir;

    vertexes.resize(capacity);
    edges.resize(capacity);

    for (int i = 0; i < capacity; i++)
        edges[i].resize(capacity, false);
}

//Complejidad: O(cap^2)
template <class T>
UMatrixGraph<T>::~matrizgrafica()
{
    vertexes.clear();
    edges.clear();
}

//Complexity: O(1)
template <class T>
void matrizgrafica<T>::adEdge(T from, T to)
{
    if (!isVertex(from))
        adVer(from);

    if (!isVertex(to))
        adVer(to);

    int i1 = getIndexOf(from);
    int i2 = getIndexOf(to);
    edges[i1][i2] = true;

    if (!directed)
        edges[i2][i1] = true;
}

//Complejidad: O(1)
template <class T>
void matrizgrafica<T>::remEdge(T from, T to)
{
    if (!isVertex(from) || !isVertex(to))
        return;

    int i1 = getIndexOf(from);
    int i2 = getIndexOf(to);
    edges[i1][i2] = false;

    if (!directed)
        edges[i2][i1] = false;
}

//Complejidad: O(1)
template <class T>
void matrizgrafica<T>::adVer(T v)
{
    if (isVertex)
        return;

    if (size < capacity)
    {
        vertexes[size++] = v;
    }
    else
    {
        throw std::invalid_argument("Graph is full");
    }
}

//Complexity: O(size^2)
template <class T>
void matrizgrafica<T>::remVer(T v)
{
    if (!isVertex(v))
        return;

    int index = getIndexOf(v);
    for (int i = index; i < size - 1; i++)
        vertexes[i] = vertexes[i + 1];

    size--;

    for (int i = index; i < size; i++)
        for (int j = 0; j < size; j++)
            edges[i][j] = edges[i + 1][j];

    for (int i = index; i < size; i++)
        for (int j = 0; j < size; j++)
            edges[j][i] = edges[j][i + 1];
}

//Complejidad: O(1)
template <class T>
bool matrizgrafica<T>::isEdge(T from, T to) const
{
    if (!isVertex(from) || !isVertex(to))
        return false;

    int iFrom = getIndexOf(from);
    int iTo = getIndexOf(to);
    return edges[iFrom][iTo];
}

//Complejidad: O(size)
template <class T>
bool matrizgrafica<T>::isVertex(T v) const
{
    return vertexes.find(v) != vertexes.end();
}

//Complejidad: O(size)
template <class T>
int matrizgrafica<T>::getIndexOf(T v) const
{
    for (int i = 0; i < size; i++)
    {
        if (vertexes[i] == v)
            return i;
    }
    return -1;
}

//Complejidad: O(1)
template <class T>
std::vector<T> matrizgrafica<T>::getVer() const
{
    return std::vector<T>(vertexes.begin(), vertexes.end());
    ;
}

//Complexity: O(size*Edges)
template <class T>
std::vector<T> matrizgrafica<T>::getNB(T v) const
{
    if (!isVertex(v))
        throw std::invalid_argument("No se encuentra el vertice");

    std::vector<T> neighbours;
    int index = getIndexOf(v);
    for (int i = 0; i < size; i++)
    {
        if (edges[index][i])
            neighbours.push_back(vertexes[i]);
    }
    return neighbours;
}

template <class T>
std::ostream &operator<<(std::ostream &os, matrizgrafica<T> &graph)
{
    os << "   ";
    for (auto v : graph.vertexes)
        os << v << " ";

    os << '\n';

    for (int i = 0; i < graph.size; i++)
    {
        os << graph.vertexes[i] << ": ";
        for (int j = 0; j < graph.size; j++)
        {
            os << graph.edges[i][j] << " ";
        }
        os << std::endl;
    }
    return os;
}
#ifndef grafica
#define grafica

#include <vector>
#include <set>
#include <stack>
#include <queue>
#include <iostream>

template <class T>
class grafica
{
public:
    void cargraf(int, std::ifstream &);

    virtual void adEdge(T, T) = 0;
    virtual void remEdge(T, T) = 0;
    virtual void adVer(T) = 0;
    virtual void remVer(T) = 0;
    virtual bool isEdge(T, T) const = 0;
    virtual bool isVertex(T) const = 0;

    virtual std::vector<T> getVert() const = 0;
    virtual std::vector<T> getNB(T) const = 0;

    std::set<T> dfs(T) const;
    std::set<T> bfs(T) const;

private:
    int size;
    bool directed;
};

//Complejidad: O(size^2)
template <class T>
std::set<T> grafica<T>::dfs(T v) const
{
    if (!isVertex(v))
        throw std::invalid_argument("No se encuentra el vertice");

    std::set<T> visited;
    std::stack<T> toSearch;
    toSearch.push(v);

    T current;
    while (!toSearch.empty())
    {
        current = toSearch.top();
        toSearch.pop();
        if (visited.find(current) == visited.end())
        {
            std::cout << current << " ";
            visited.insert(current);
            for (auto elem : getNeighbours(current))
                toSearch.push(elem);
        }
    }
    std::cout << std::endl;

    return visited;
}

//Complexity: O(size^2)
template <class T>
std::set<T> grafica<T>::bfs(T v) const
{
    if (!isVertex(v))
        throw std::invalid_argument("Vertice no encontrado");

    std::set<T> visited;
    std::queue<T> toSearch;
    toSearch.push(v);

    T current;
    while (!toSearch.empty())
    {
        current = toSearch.front();
        toSearch.pop();
        if (visited.find(current) == visited.end())
        {
            std::cout << current << " ";
            visited.insert(current);
            for (auto elem : getNeighbours(current))
                toSearch.push(elem);
        }
    }
    std::cout << std::endl;

    return visited;
}

template <class T>
void grafica<T>::loadGraph(int n, std::ifstream &inputFile)
{
    size = n;
    int iFrom, iTo;

    inputFile >> iFrom >> iTo;

    while (iFrom && iTo)
    {
        inputFile >> iFrom >> iTo;
        adEdge(iFrom, iTo);
    }
}

#endif
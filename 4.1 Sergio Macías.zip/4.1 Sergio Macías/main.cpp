#include "matrizgrafica.cpp"
#include "listagrafica.cpp"

int main(int argc, char *argv[])
{
    listagrafica<char> graph(true);
    graph.adVer('A');
    graph.adVer('B');
    graph.adVer('C');
    graph.adVer('D');
    graph.adVer('E');
    graph.adEdge('A', 'B');
    graph.adEdge('A', 'C');
    graph.adEdge('B', 'C');
    graph.adEdge('B', 'D');
    graph.adEdge('C', 'D');
    graph.adEdge('C', 'E');
    graph.adEdge('D', 'E');
    graph.dfs('B');
    std::cout << std::endl;
    graph.bfs('B');
    std::cout << std::endl;
    std::cout << graph;
    return 0;
}